﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibC
{
    public interface IClassD
    {
    }
}

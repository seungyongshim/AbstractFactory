﻿using LibC;
using System;

namespace LibD
{
    public class ClassD : IClassD
    {
        public override string ToString()
        {
            return nameof(ClassD);
        }
    }
}

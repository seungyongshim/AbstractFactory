﻿namespace Lib
{
    public interface IClassA
    {
    }
}
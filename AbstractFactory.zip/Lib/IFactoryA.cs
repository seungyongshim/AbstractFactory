﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lib
{
    public interface IFactoryA
    {
        IClassA Create();
    }
}

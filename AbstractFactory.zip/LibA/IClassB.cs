﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibA
{
    public interface IClassB
    {
    }
}

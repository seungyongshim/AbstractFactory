﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibA
{
    public interface IFactoryB
    {
        IClassB Create();
    }
}
